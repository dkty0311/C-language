#pragma once
int choice_menu();
void end_menu();
void start_menu();