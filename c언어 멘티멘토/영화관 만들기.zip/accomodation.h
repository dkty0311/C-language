#pragma once
#define SIZE 10
#define INFORM 5
void accomodation(int seats[SIZE][SIZE], int rep_check_l);
void accomodation_cancel(int seats[SIZE][SIZE], int rep_check_l);



struct accomodation
{
	int seats[10][10];
};